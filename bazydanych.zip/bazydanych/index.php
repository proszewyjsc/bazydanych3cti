<?php

print "<!DOCTYPE html>\n";
print "<html lang=\"pl\">\n";
print "<head>\n";
print "    <meta charset=\"utf-8\"/>\n";
print "    <title>Tabela</title>\n";
print "    <style> td, th { border: 1px solid black; } </style>\n";
print "    <link rel=\"stylesheet\" href=\"styl.css\"\n";
print "</head>\n";
print "<body>\n";
print "        <h1>Tabelka</h1><br><br><br><br><br><br><br><br><br>\n";
print "    <table>\n";
print "        <thead>\n";
print "            <tr>\n";
print "               <th>Nazwisko</th> <th>Rola</th> \n";
print "            </tr>\n";
print "            <tr>\n";
print "                <td>Jakub Krajewski</td> <td>DevOps</td> \n";
print "\n";
print "\n";
print "            </tr>\n";
print "            <tr>\n";
print "                <td>Dariusz Tomasik</td> <td>Team Leader</td> \n";
print "            </tr>\n";
print "            <tr>\n";
print "                <td>Łukasz Łapkiewicz</td> <td>Tester</td> \n";
print "            </tr>\n";
print "        </thead>\n";
print "\n";
print "\n";
print "\n";
print "    </table>\n";
print "\n";
print "</body>";

?>
